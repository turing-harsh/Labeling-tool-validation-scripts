digest ok
