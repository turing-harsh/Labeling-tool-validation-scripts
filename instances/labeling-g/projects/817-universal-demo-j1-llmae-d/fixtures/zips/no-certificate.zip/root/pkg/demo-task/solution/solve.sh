#!/bin/sh
echo solved
