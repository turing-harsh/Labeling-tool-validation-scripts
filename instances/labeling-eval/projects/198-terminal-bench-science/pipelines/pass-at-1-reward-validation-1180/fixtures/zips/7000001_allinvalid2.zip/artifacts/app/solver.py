print('solve')
